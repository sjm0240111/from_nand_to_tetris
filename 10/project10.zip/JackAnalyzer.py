# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 21:13:19 2017

@author: John Lee
"""

import os
import re
import sys
from compilengine import *

def main(fname):
    if os.path.isfile(fname):                         # user gives one file
        #print(fname)
        analyzefile(fname)
        
    elif os.path.isdir(fname):                       # user gives one directory        
        filelist = list()
        for file in os.listdir(fname):                         # get all jack files
            if file.split(sep='.')[-1] == 'jack':
                pathedfile = os.path.join(fname, file)
                filelist.append(pathedfile)
        #print(filelist)
        if len(filelist) == 0:
            print('no jack file exist')
            exit()                                            
        for pf in filelist:                              # translating all
            analyzefile(pf)
    else:
        print('no such file or directory')

def parseword(text):
    comment = r'//.*\n|/\*[\s\S]*?\*/'
    symbolptn = r'(\{)|(\})|(\()|(\))|(\[)|(\])|(\.)|(\,)|(;)|(\+)|'\
    +'(\-)|(\*)|(/)|(&)|(\|)|(<)|(>)|(=)|(~)'
    symbolrpl = r' \1\2\3\4\5\6\7\8\9\10\11\12\13\14\15\16\17\18\19 '
    text = re.sub(comment, ' ',text)               # remove comment
    _roughlist = text.split('"')
    i = 1
    wordlist = list()
    while i < len(_roughlist):
        _subtext = re.sub(symbolptn, symbolrpl, _roughlist[i-1])       # separate elements
        _subtext = _subtext.strip() 
        wordlist = wordlist + re.split(r'\s+', _subtext) 
        wordlist.append('"'+_roughlist[i])
        i = i+2
    _subtext = re.sub(symbolptn, symbolrpl, _roughlist[i-1])      
    _subtext = _subtext.strip() 
    wordlist = wordlist + re.split(r'\s+', _subtext) 
    return wordlist     

def analyzefile(jackfile):
    with open(jackfile, 'r') as myfile:
        text = myfile.read()
    wordlist = parseword(text)
    namexml = re.sub(r'.jack','.xml',jackfile)
    fout = open(namexml, 'w')
    jackobj = CompileEngine(wordlist,fout)
    #jackobj.tokenize(len(wordlist))
    jackobj.compileClass()
    fout.close()
            
main(sys.argv[1])  